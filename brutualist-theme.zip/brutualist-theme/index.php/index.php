<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style>
        body { background-color: #f4f4f0; font-family: sans-serif; }
        h1, h2, h3, .serif { font-family: 'Playfair Display', serif; }
        .brutal-border { border: 4px solid #000; }
        .brutal-shadow { box-shadow: 8px 8px 0px #000; }
        .article-row { border-bottom: 2px solid #000; transition: all 0.2s ease; }
        
        /* The signature hover inversion effect */
        .article-row:hover { background-color: #000; color: #fff; }
        .article-row:hover h2 a, .article-row:hover time { color: #fff; }
        .article-row:hover .excerpt-text { color: #d1d5db; }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,800;1,400&display=swap" rel="stylesheet">
</head>
<body <?php body_class('p-4 md:p-8'); ?>>
    
    <div class="max-w-5xl mx-auto">
        <!-- Compact Author Section -->
        <header class="mb-12 brutal-border p-6 md:p-8 brutal-shadow bg-white flex flex-col md:flex-row items-center gap-6">
            <div>
                <h1 class="text-4xl md:text-5xl font-extrabold serif mb-2 tracking-tighter uppercase">
                    <?php bloginfo('name'); ?>
                </h1>
                <p class="text-lg font-medium max-w-2xl text-gray-800">
                    <?php 
                    $description = get_bloginfo('description', 'display');
                    if ( $description ) : 
                        echo $description; 
                    else : 
                        // Pre-filled fallback text
                        echo 'Writer specializing in digital comedy, scriptwriting, and SEO. Exploring the absurdities of modern digital culture, one post at a time.';
                    endif; 
                    ?>
                </p>
            </div>
        </header>

        <!-- Blog Feed (The WordPress Loop) -->
        <main class="brutal-border bg-white">
            <div class="bg-black text-white p-4 uppercase font-bold tracking-widest text-xs border-b-4 border-black">
                Index / Latest Writing
            </div>

            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <article class="article-row group p-6 md:p-8 block relative cursor-pointer" onclick="window.location='<?php the_permalink(); ?>';">
                    <div class="flex flex-col md:flex-row md:items-baseline gap-2 md:gap-8 justify-between">
                        <h2 class="text-2xl md:text-4xl font-bold serif">
                            <a href="<?php the_permalink(); ?>" class="text-black group-hover:text-white transition-colors">
                                <?php the_title(); ?>
                            </a>
                        </h2>
                        <time class="text-sm font-mono uppercase whitespace-nowrap text-gray-600 transition-colors">
                            <?php echo get_the_date(); ?>
                        </time>
                    </div>
                    
                    <div class="mt-4 excerpt-text text-gray-700 text-lg hidden md:block">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; else : ?>
                <div class="p-8"><p class="font-mono uppercase">No content published yet.</p></div>
            <?php endif; ?>

        </main>
    </div>

    <?php wp_footer(); ?>
</body>
</html>