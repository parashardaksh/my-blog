<?php
function brutalist_theme_scripts() {
    // Loads Tailwind CSS via CDN for rapid deployment
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com', array(), null, false);
}
add_action('wp_enqueue_scripts', 'brutalist_theme_scripts');

function brutalist_theme_setup() {
    // Allows WordPress to manage the document title
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'brutalist_theme_setup');
?>